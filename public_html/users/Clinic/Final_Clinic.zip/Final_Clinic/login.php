<?php 
	include 'conn.php';	
    

	session_start();

	$uname = $_REQUEST['uname'];
	$pword = $_REQUEST['pword'];

	$sql = "call spLogIn(?,?)";
	$stmt = mysqli_stmt_init($conn);
				
	if (!mysqli_stmt_prepare($stmt,$sql)){
		echo "SQL statement failed!";
	} else {
		mysqli_stmt_bind_param($stmt,"ss", $uname,$pass);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		$rowCount = mysqli_num_rows($result);
		if ($rowCount>0){
			while ($row = mysqli_fetch_assoc($result)){	
				$userpass = $row['password'];
                $cipher = "AES-128-CTR";     
                $iv_length = openssl_cipher_iv_length($cipher); 
                $options = 0; 
                // Non-NULL Initialization Vector for decryption 
                $decryption_iv = '1234567891011121';    
                // Store the decryption key 
                $decryption_key = "HallsofLife"; 
                // Use openssl_decrypt() function to decrypt the data 
                $decryption=openssl_decrypt ($userpass, $cipher, $decryption_key, $options, $decryption_iv); 
                // echo $decryption;
				if ($pword==$decryption){

						$type = $row['type'];
						if (empty($row['photo'])) $row['photo'] = file_get_contents("../img/default.png");
						$photo = base64_encode($row['photo']);
						$_SESSION["user_name"] = $row['name'];
						$_SESSION["id"] = $row['id'];
						$_SESSION['type'] = $type;
						$_SESSION['campusid'] = $row['campid'];
						$_SESSION['branch'] = $row['campname'];
						$_SESSION['currentyear'] = $row['acadyear'];
						$_SESSION['currenttrim'] = $row['acadtrim'];
						$_SESSION['photo'] = $photo;
						$activity = 'Successfully Logged in.';
						$page = '/hlbc2/Log-in.html';
						log_activity($activity,$page);
						if ($type=='Student'){
						    $_SESSION['msgcount'] = $row['msgcnt'];
							echo "<script>location.href=\"../Users/Student/\"</script>";
						}
						if ($type=='Teacher'){
							echo "<script>location.href=\"../Users/Teacher/\"</script>";
						}
						if ($type=='Dean'){
							echo "<script>location.href=\"../Users/Dean/\"</script>";
						}
						if ($type=='Registrar'){
							echo "<script>location.href=\"../Users/Registrar/\"</script>";
						}
				}
				else {
					$activity = 'Incorrect Password.';
						$page = '/hlbc2/Log-in.html';
						log_activity($activity,$page);
        			echo "<script>alert(\"Incorrect Password!\")</script>";
        			echo "<script>location.href=\"../Log-in.html\"</script>";
				}
			}
		} 
		else {
			echo "<script>alert(\"Incorrect username or user not found\")</script>";
    		echo "<script>location.href=\"../Log-in.html\"</script>";
		}

	}