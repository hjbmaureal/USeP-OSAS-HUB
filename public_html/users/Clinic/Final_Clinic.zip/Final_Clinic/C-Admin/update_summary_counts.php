<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<!--set appointment modal-->
<!--add -->
<?php
if(isset($_POST['AddEntry'])){			
   $patient_id= $_POST['username'];
   $comment= $_POST['comment'];	
   $bp_reading= $_POST['reading'];
  /* 
   $referhos= $_POST['referhos'];
   $referphy= $_POST['referphy'];
   $referlab= $_POST['referlab'];
   $referden= $_POST['referden'];
   $dressing = $_POST['dressing'];*/
   	
   //bp_reading
   if($row['service_id']==1){
   
   $sql="INSERT INTO bp_reading(patient_id,bp_reading,bp_comment,bp_date) VALUES('$patient_id', '$bp_reading', '$comment',NOW())";
    if ($db->query($sql) === TRUE) {
  echo '<script>alert("BP Results inserted successfully!");</script>';
  }else {
  echo '<script>alert("Failed!Try Again!"); </script>';
}
   } 
   }
   ?>
<div class="modal fade " id="update_summary<?php echo $row['service_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header" style="background-color: #2B4550">
      <h5 class="modal-title" id="exampleModalLongTitle" style="color: #FFFFFF"><?php echo $row['service_name']; ?></h5>
      <button type="button" class="close" data-dismiss="modal" style="color: #FFFFFF" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
    </div>
    <div class="modal-body c">
    <div class="container">
    <form method="post">
     
      <?php
if($row['service_id']==1){
?>      <div class="form-group row">
        <label class="control-label col-md-4">Student ID No:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="username" id="username" placeholder="Enter ID No.">
          <span id="availability"></span> </div>
      </div>
      <div class="form-group row">
        <label class="control-label col-md-4">Blood Pressure Reading:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="reading" id="reading" placeholder="Enter Results">
        </div>
      </div>
      <?php
}if($row['service_id']==2){
?>
 <div class="form-group row">
        <label class="control-label col-md-4">Student ID No:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="username" id="username" placeholder="Enter ID No.">
          <span id="availability"></span> </div>
      </div>
       <div class="form-group row">
        <label class="control-label col-md-4">FBS/RBS Result:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="fbs" id="fbs" placeholder="Enter Results">
        </div>
      </div>
       <?php
}if($row['service_id']==3){
?>
       <div class="form-group row">
        <label class="control-label col-md-4">Refer to Physician:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="referphy" id="referphy" placeholder="Enter Results">
        </div>
      </div>
      <?php
}if($row['service_id']==4){
?>
       <div class="form-group row">
        <label class="control-label col-md-4">Refer to Hospital:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="referhos" id="referhos" placeholder="Refer to Hospital">
        </div>
      </div>
     <?php
}if($row['service_id']==5){
?>
       <div class="form-group row">
        <label class="control-label col-md-4">Refer to Laboratory:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="referlab" id="referlab" placeholder="Refer to Laboratory">
        </div>
      </div>
       <?php
}if($row['service_id']==6){
?>
       <div class="form-group row">
        <label class="control-label col-md-4">Refer to Dentist:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="referden" id="referden" placeholder="Refer to Dentist">
        </div>
      </div>
      <?php
}if($row['service_id']==7){
?>
       <div class="form-group row">
        <label class="control-label col-md-4">Dressing:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="dressing" id="dressing" placeholder="Dressing">
        </div>
      </div>
      <?php
}if($row['service_id']==8){
?>
       <div class="form-group row">
        <label class="control-label col-md-4">Warm/Cold Compress:</label>
        <div class="col-md-8">
          <input class="form-control col-md-8" type="text" name="compress" id="compress" >
        </div>
      </div>
      <?php
}
?>    <div class="form-group row">
        <label class="control-label col-md-4">Comment/s:</label>
        <div class="col-md-8">
          <textarea class="form-control col-md-8" type="text" name="comment" id="comment" placeholder="Add comments" required></textarea>
        </div>
      </div>
	 
      <br>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger"  data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success" name="AddEntry">Add</button>
      </div>
    </form>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<script>  
 $(document).ready(function(){  
   $('#username').blur(function(){

     var username = $(this).val();

     $.ajax({
      url:'check.php',
      method:"POST",
      data:{username:username},
      success:function(data)
      {
       if(data != '0')
       {
        $('#availability').html('<span class="text-success">Registered!</span>');
        $('#register').attr("disabled", true);
       }
       else
       {
        $('#availability').html('<span class="text-danger">Not Registered. Please Register!</span>');
        $('#register').attr("disabled", false);
       }
      }
     })

  });
 });  
</script>
