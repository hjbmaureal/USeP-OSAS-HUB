<?php
include_once('connect.php');
							  if(isset($_POST['resched'])){			
   $pat_id= $_POST['id'];
   $patient_id= $_POST['patient_id'];
   $name= $_POST['name'];	
   $mode=$_POST['mode'];
    $mode2=$_POST['mode2'];
   $type=$_POST['type'];
   $date=$_POST['date'];
   $start = $_POST['start'];
   $end = $_POST['end'];
   $link= $_POST['link'];
   $email =$_POST['email'];
	
   $sql = "Update consultation set appointment_date='$date', appointment_timefrom='$start',appointment_timeto='$end' , status='Ongoing', appointment_meetinglink='$link' where id='$pat_id'"; 
   if ($db->query($sql) === TRUE) {
  echo '<script>alert("Appointment set successfully!");</script>';
  if($link == "N/A"){
  $to_email = 'tjbinso@usep.edu.ph';
$name = $_REQUEST['name'];
$date =date_create($_REQUEST['date']);
$date1 = date_format($date,"F d, Y");
$start = $_REQUEST['start'];
$starts = date('h:i A', strtotime($start));
$end = $_REQUEST['end'];
$ends = date('h:i A', strtotime($end));
$link = $_REQUEST['link'];
$fb = $_REQUEST['facebook'];
$mode2 = $_REQUEST['mode2'];
$subject = "Reschedule of Appointment";
$body ="Good day  $name,\n \n Your appointment has been reschedule and has been moved on $date1 at $starts to $ends. The mode of communication you choose is $mode2.\nContact them at the given Facebook link $fb at the given time above.  \n \n Sincerely, \n USeP Tagum-Mabini Clinic";
$headers = "From: USeP Tagum-Mabini Clinic";
 

}if($link != "N/A" && $link != "Voice Call"){
  $to_email = 'tjbinso@usep.edu.ph';
$name = $_REQUEST['name'];
$date =date_create($_REQUEST['date']);
$date1 = date_format($date,"F d, Y");
$start = $_REQUEST['start'];
$starts = date('h:i A', strtotime($start));
$end = $_REQUEST['end'];
$ends = date('h:i A', strtotime($end));
$link = $_REQUEST['link'];
$mode2 = $_REQUEST['mode2']; 
$subject = "Reschedule of Appointment";
$body =" Good day $name,\n \n Your appointment has been reschedule and has been moved on $date1 at  $starts to $ends. The mode of communication you choose is $mode2.\n Click the link $link at the given time above to start your consultation. \n  \n  Sincerely, \n USeP Tagum-Mabini Clinic";
$headers = "From: USeP Tagum-Mabini Clinic";
 

}if($link == "Voice Call"){

}
 echo "<script type='text/javascript'> document.location = 'Admin-ListOfConsultation.php'; </script>";
} else {
  echo '<script>alert("Failed!Try Again!"); </script>';
}
}

   ?>