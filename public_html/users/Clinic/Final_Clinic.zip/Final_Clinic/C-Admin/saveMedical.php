<?php
include_once("connect.php");
 
  if(isset($_POST['Submit'])){  
    $id = $_POST['id']; 
    $patient_id = $_POST['idnum'];
    $general = $_POST['general'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $pulse = $_POST['pulse'];
    $respiration = $_POST['respiration'];
    $temperature = $_POST['temperature'];
    $infect = $_POST['infect'];
    $social = $_POST['social'];
    $family = $_POST['family'];
    $system = $_POST['system'];
    $skin = $_POST['skin'];
    $lymph = $_POST['lymph'];
    $integ = $_POST['integ'];
    $circulatory = $_POST['circulatory'];
    $endocrine = $_POST['endocrine'];
    $allergic = $_POST['allergic'];
    $heent = $_POST['heent'];
    $mouth = $_POST['mouth'];
    $breast = $_POST['breast'];
    $respiratory = $_POST['respiratory'];
    $cardio = $_POST['cardio'];
    $gastro = $_POST['gastro'];
    $geni = $_POST['geni'];
    $psy = $_POST['psy'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    $remarks = $_POST['remarks'];
    $preslist = $_POST['preslist'];
    $status = $_POST['Status'];
        
        
    // checker
    if(empty($general)|| empty($height)|| empty($weight)|| empty($pulse)|| empty($respiration)|| empty($temperature)|| empty($infect)|| empty($social)|| empty($family)|| empty($system)|| empty($skin)|| empty($lymph)|| empty($integ)|| empty($circulatory)|| empty($endocrine)|| empty($allergic)|| empty($heent)|| empty($mouth)|| empty($breast)|| empty($respiratory)|| empty($cardio)|| empty($gastro)|| empty($geni)|| empty($psy)|| empty($diagnosis)|| empty($treatment)|| empty($remarks)|| empty($preslist)|| empty($status)) { 

        
        if(empty($general)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }  
        if(empty($height)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($weight)) {
            echo "<font color='red'>field is empty.</font><br/>";
        } 
        if(empty($pulse)) {
            echo "<font color='red'>field is empty.</font><br/>";
        } 
        if(empty($respiration)) {
            echo "<font color='red'>field is empty.</font><br/>";
        } 
        if(empty($temperature)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($infect)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($social)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($family)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($system)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($skin)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($lymph)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($integ)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($circulatory)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($endocrine)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($allergic)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($heent)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($mouth)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($breast)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($respiratory)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($cardio)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($gastro)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($geni)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($psy)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($diagnosis)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($treatment)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($remarks)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($preslist)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        if(empty($status)) {
            echo "<font color='red'>field is empty.</font><br/>";
        }
        
        //go back ni
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    } else { 
        
        //insert syntax
        $result ="INSERT INTO patient_health_record_medical(patient_id,general_appearance,height,weight,pulse_rate,respiration_rate,temperature,infectious_disease,social_history,family_history,system_review,skin,lymph_nodes,integument_system,circulatory_system, endocrine_system, allergic_immunologic_history, heent, mouth, breast, respiratory_system, cardiovascular_system, gastrointestinal_system, genitourinary_tract, psychiatric_history, date_filled_out_by_nurse) VALUES('$patient_id','$general','$height','$weight','$pulse','$respiration','$temperature','$infect','$social','$family','$system','$skin','$lymph','$integ','$circulatory','$endocrine','$allergic','$heent','$mouth','$breast','$respiratory','$cardio','$gastro','$geni','$psy', now())";

          if ($db->query($result) === TRUE) {

            $res ="UPDATE consultation 
                  SET diagnosis='$diagnosis', treatment='$treatment', remarks='$remarks',status='$status', prescription_details='$preslist', prescription_date_issued=now()
                  WHERE id ='$id'";
        if ($db->query($res) === TRUE) {
       
          echo '<script>alert("Data added successfully!");</script>';

          echo "<script type='text/javascript'> document.location = 'Admin-ListOfConsultation.php'; </script>";
                exit();
           
    
    }}else{

  echo '<script>alert("Failed!Try Again!"); </script>';
}
}
}
?>