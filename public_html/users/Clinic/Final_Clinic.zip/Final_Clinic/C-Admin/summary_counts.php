<?php //bsa
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND coursetitle='BSA' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count1 = mysqli_num_rows($res);
?>
<?php //btvte
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND coursetitle='BTVTE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count2 = mysqli_num_rows($res);
?>
<?php //bece
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND coursetitle='BECE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count3 = mysqli_num_rows($res);
?>
<?php //bsned
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND coursetitle='BSNED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count4 = mysqli_num_rows($res);
?>
<?php //beed
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND coursetitle='BEED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count5 = mysqli_num_rows($res);
?>
<?php //bsabe
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND coursetitle='BSABE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count6 = mysqli_num_rows($res);
?>
<?php //bsf
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND coursetitle='BSF' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count7 = mysqli_num_rows($res);
?>
<?php //bsit
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND coursetitle='BSIT' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count8 = mysqli_num_rows($res);
?>
<?php //cars-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND patient_type='CARS-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count9 = mysqli_num_rows($res);
?>
<?php //cars-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND patient_type='CARS-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count10 = mysqli_num_rows($res);
?>
<?php //ctet-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND patient_type='CTET-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count11 = mysqli_num_rows($res);
?>
<?php //ctet-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND patient_type='CTET-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count12 = mysqli_num_rows($res);
?>
<?php //faculty
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND patient_type='Faculty' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count13 = mysqli_num_rows($res);
?>
<?php //Staff
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND patient_type='Staff' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count14 = mysqli_num_rows($res);
?>
<?php //ext
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '01' AND consultation.consultation_type='03'  AND patient_type='Ext' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count15 = mysqli_num_rows($res);
?>
<?php //total1
				
 $date = date('Y');
      $sql= "SELECT EXTRACT(month FROM date_filed),consultation_type from consultation 
WHERE EXTRACT(MONTH FROM date_filed) = '01' AND consultation_type='03' AND EXTRACT(YEAR FROM date_filed) = $date
ORDER BY EXTRACT(month FROM date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_total1 = mysqli_num_rows($res);
?>
<!--February-->
<?php //bsa
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND coursetitle='BSA' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count101 = mysqli_num_rows($res);
?>
<?php //btvte
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND coursetitle='BTVTE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count102 = mysqli_num_rows($res);
?>
<?php //bece
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND coursetitle='BECE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count103 = mysqli_num_rows($res);
?>
<?php //bsned
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND coursetitle='BSNED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count104 = mysqli_num_rows($res);
?>
<?php //beed
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND coursetitle='BEED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count105 = mysqli_num_rows($res);
?>
<?php //bsabe
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND coursetitle='BSABE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count106 = mysqli_num_rows($res);
?>
<?php //bsf
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND coursetitle='BSF' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count107 = mysqli_num_rows($res);
?>
<?php //bsit
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND coursetitle='BSIT' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count108 = mysqli_num_rows($res);
?>
<?php //cars-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND patient_type='CARS-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count109 = mysqli_num_rows($res);
?>
<?php //cars-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND patient_type='CARS-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count110 = mysqli_num_rows($res);
?>
<?php //ctet-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND patient_type='CTET-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count111 = mysqli_num_rows($res);
?>
<?php //ctet-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND patient_type='CTET-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count112 = mysqli_num_rows($res);
?>
<?php //faculty
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND patient_type='Faculty' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count113 = mysqli_num_rows($res);
?>
<?php //Staff
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND patient_type='Staff' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count114 = mysqli_num_rows($res);
?>
<?php //ext
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03'  AND patient_type='Ext' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count115 = mysqli_num_rows($res);
?>
<?php //total1
				
 $date = date('Y');
   $sql= "SELECT EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '02' AND consultation.consultation_type='03' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count116 = mysqli_num_rows($res);
?>
<!--March-->
<?php //bsa
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND coursetitle='BSA' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count201 = mysqli_num_rows($res);
?>
<?php //btvte
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND coursetitle='BTVTE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count202 = mysqli_num_rows($res);
?>
<?php //bece
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND coursetitle='BECE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count203 = mysqli_num_rows($res);
?>
<?php //bsned
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND coursetitle='BSNED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count204 = mysqli_num_rows($res);
?>
<?php //beed
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND coursetitle='BEED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count205 = mysqli_num_rows($res);
?>
<?php //bsabe
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND coursetitle='BSABE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count206 = mysqli_num_rows($res);
?>
<?php //bsf
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND coursetitle='BSF' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count207 = mysqli_num_rows($res);
?>
<?php //bsit
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND coursetitle='BSIT' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count208 = mysqli_num_rows($res);
?>
<?php //cars-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND patient_type='CARS-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count209 = mysqli_num_rows($res);
?>
<?php //cars-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND patient_type='CARS-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count210 = mysqli_num_rows($res);
?>
<?php //ctet-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND patient_type='CTET-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count211 = mysqli_num_rows($res);
?>
<?php //ctet-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND patient_type='CTET-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count212 = mysqli_num_rows($res);
?>
<?php //faculty
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND patient_type='Faculty' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count213 = mysqli_num_rows($res);
?>
<?php //Staff
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND patient_type='Staff' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count214 = mysqli_num_rows($res);
?>
<?php //ext
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03'  AND patient_type='Ext' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count215 = mysqli_num_rows($res);
?>
<?php //total1
				
 $date = date('Y');
   $sql= "SELECT EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '03' AND consultation.consultation_type='03' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count216 = mysqli_num_rows($res);
?>

<!--April-->
<?php //bsa
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND coursetitle='BSA' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count301 = mysqli_num_rows($res);
?>
<?php //btvte
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND coursetitle='BTVTE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count302 = mysqli_num_rows($res);
?>
<?php //bece
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND coursetitle='BECE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count303 = mysqli_num_rows($res);
?>
<?php //bsned
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND coursetitle='BSNED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count304 = mysqli_num_rows($res);
?>
<?php //beed
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND coursetitle='BEED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count305 = mysqli_num_rows($res);
?>
<?php //bsabe
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND coursetitle='BSABE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count306 = mysqli_num_rows($res);
?>
<?php //bsf
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND coursetitle='BSF' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count307 = mysqli_num_rows($res);
?>
<?php //bsit
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND coursetitle='BSIT' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count308 = mysqli_num_rows($res);
?>
<?php //cars-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND patient_type='CARS-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count309 = mysqli_num_rows($res);
?>
<?php //cars-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND patient_type='CARS-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count310 = mysqli_num_rows($res);
?>
<?php //ctet-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND patient_type='CTET-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count311 = mysqli_num_rows($res);
?>
<?php //ctet-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND patient_type='CTET-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count312 = mysqli_num_rows($res);
?>
<?php //faculty
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND patient_type='Faculty' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count313 = mysqli_num_rows($res);
?>
<?php //Staff
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND patient_type='Staff' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count314 = mysqli_num_rows($res);
?>
<?php //ext
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03'  AND patient_type='Ext' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count315 = mysqli_num_rows($res);
?>
<?php //total1
				
 $date = date('Y');
   $sql= "SELECT EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '04' AND consultation.consultation_type='03' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count316 = mysqli_num_rows($res);
?>

<!--May-->
<?php //bsa
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND coursetitle='BSA' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count401 = mysqli_num_rows($res);
?>
<?php //btvte
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND coursetitle='BTVTE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count402 = mysqli_num_rows($res);
?>
<?php //bece
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND coursetitle='BECE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count403 = mysqli_num_rows($res);
?>
<?php //bsned
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND coursetitle='BSNED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count404 = mysqli_num_rows($res);
?>
<?php //beed
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND coursetitle='BEED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count405 = mysqli_num_rows($res);
?>
<?php //bsabe
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND coursetitle='BSABE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count406 = mysqli_num_rows($res);
?>
<?php //bsf
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND coursetitle='BSF' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count407 = mysqli_num_rows($res);
?>
<?php //bsit
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND coursetitle='BSIT' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count408 = mysqli_num_rows($res);
?>
<?php //cars-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND patient_type='CARS-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count409 = mysqli_num_rows($res);
?>
<?php //cars-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND patient_type='CARS-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count410 = mysqli_num_rows($res);
?>
<?php //ctet-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND patient_type='CTET-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count411 = mysqli_num_rows($res);
?>
<?php //ctet-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND patient_type='CTET-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count412 = mysqli_num_rows($res);
?>
<?php //faculty
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND patient_type='Faculty' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count413 = mysqli_num_rows($res);
?>
<?php //Staff
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND patient_type='Staff' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count414 = mysqli_num_rows($res);
?>
<?php //ext
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03'  AND patient_type='Ext' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count415 = mysqli_num_rows($res);
?>
<?php //total1
				
 $date = date('Y');
   $sql= "SELECT EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '05' AND consultation.consultation_type='03' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count416 = mysqli_num_rows($res);
?>

<!--June-->
<?php //bsa
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND coursetitle='BSA' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count501 = mysqli_num_rows($res);
?>
<?php //btvte
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND coursetitle='BTVTE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count502 = mysqli_num_rows($res);
?>
<?php //bece
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND coursetitle='BECE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count503 = mysqli_num_rows($res);
?>
<?php //bsned
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND coursetitle='BSNED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count504 = mysqli_num_rows($res);
?>
<?php //beed
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND coursetitle='BEED' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count505 = mysqli_num_rows($res);
?>
<?php //bsabe
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND coursetitle='BSABE' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count506 = mysqli_num_rows($res);
?>
<?php //bsf
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND coursetitle='BSF' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count507 = mysqli_num_rows($res);
?>
<?php //bsit
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND coursetitle='BSIT' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count508 = mysqli_num_rows($res);
?>
<?php //cars-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND patient_type='CARS-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count509 = mysqli_num_rows($res);
?>
<?php //cars-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND patient_type='CARS-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count510 = mysqli_num_rows($res);
?>
<?php //ctet-m
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND patient_type='CTET-M' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count511 = mysqli_num_rows($res);
?>
<?php //ctet-d
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND patient_type='CTET-D' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count512 = mysqli_num_rows($res);
?>
<?php //faculty
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND patient_type='Faculty' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count513 = mysqli_num_rows($res);
?>
<?php //Staff
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND patient_type='Staff' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count514 = mysqli_num_rows($res);
?>
<?php //ext
				
 $date = date('Y');
   $sql= "SELECT studentdetails.coursetitle,EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03'  AND patient_type='Ext' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count515 = mysqli_num_rows($res);
?>
<?php //total1
				
 $date = date('Y');
   $sql= "SELECT EXTRACT(month FROM consultation.date_filed) from consultation join studentdetails on consultation.patient_id=studentdetails.student_id 
WHERE EXTRACT(MONTH FROM consultation.date_filed) = '06' AND consultation.consultation_type='03' AND EXTRACT(YEAR FROM consultation.date_filed) = $date
ORDER BY EXTRACT(month FROM consultation.date_filed);";
  $res = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($res,MYSQLI_ASSOC);
   $bp_count516 = mysqli_num_rows($res);
?>


