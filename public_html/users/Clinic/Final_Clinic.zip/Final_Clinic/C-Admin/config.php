<?php

$dbhost = 'localhost';
$dbname = 'osasdb_latest4';
$dbusername ='root';
$dbpassword = '';


$mysqli = mysqli_connect($dbhost,$dbusername,$dbpassword,$dbname);

?>