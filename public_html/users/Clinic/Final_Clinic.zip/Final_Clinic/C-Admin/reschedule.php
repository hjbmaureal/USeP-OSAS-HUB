<!--set appointment modal-->
				
				 <div class="modal fade " id="exampleModalLong2<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header" style="background-color: #2B4550">
                        <h5 class="modal-title" id="exampleModalLongTitle" style="color: #FFFFFF">SET APPOINTMENT</h5>
                        <button type="button" class="close" data-dismiss="modal" style="color: #FFFFFF" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body c">
                        <div class="container">
                          <form method="post" action="rescheduleapp.php">  

       
                            <div class="row">
                            <div class="col-sm">
                              <div class="appointment_box">
                               <h5 class="font-weight-bold">Type of Consultation:<input type="hidden" name="type" class="form-control" value="<?php echo htmlentities($row['consultation_type']);?>"> <span class="font-weight-lighter ml-6"><?php echo htmlentities($row['consultation_type']);?></span></h5> 
							   
							   
                                <h5 class="font-weight-bold">Mode of Communication:<input type="hidden" name="mode" class="form-control" value="<?php echo htmlentities($row['communication_mode']);?>"> <span class="font-weight-lighter ml-6"><input type="hidden" name="mode2" class="form-control" value="<?php echo htmlentities($row['communication_mode']);?>"> <span class="font-weight-lighter ml-6"><?php echo htmlentities($row['communication_mode']);?></span></h5> 
                                <br>
		
                              <h6 class="font-weight-bold">Patient ID:  <input type="hidden" name="id" class="form-control" value="<?php echo htmlentities($row['patient_id']);?>"> <span class="font-weight-lighter ml-6"><u><?php echo htmlentities($row['patient_id']);?></u></span></h6> 
                              <h6 class="font-weight-bold">Patient Name:  <input type="hidden" name="name" class="form-control" value=" <?php echo htmlentities($row['name']);?>"> <span class="font-weight-lighter ml-2"><u> <?php echo htmlentities($row['name']);?></u></span></h6>
                               <h6 class="font-weight-bold">Email: <input type="hidden" name="email" class="form-control" value="<?php echo htmlentities($row['email_add']);?>"><span class="font-weight-lighter ml-6"><u><?php echo htmlentities($row['email_add']);?></u></span></h6> 
                          
                              
                              <br> 
							
                              <div class="form-row">
                                      <div class="form-group col-md-6">
                                        <label class=" control-label"><b>Date</b></label>
                                        <input type="date" name="date" id="appdate"  class="form-control" onChange="getDay(this.value);" min="<?php echo date('Y-m-d');?>" value="<?php echo htmlentities($row['appointment_date']);?>">
										 <span id="closed"></span>
								 <input type="hidden" name="patient_id" class="form-control" value="<?php echo htmlentities($row['patient_id']);?>">
								 <input type="hidden" name="id" class="form-control" value="<?php echo htmlentities($row['id']);?>"> 
								
                                      </div>
									  </div>
									
									   <div class="form-row">
									  <div id="datestatus"> </div>
                                      <div class="form-group col-md-6">
                                        <label class=" control-label"><b>Start Time:</b></label>
                                       <input type="time" name="start" id="start" class="form-control" value="<?php echo htmlentities($row['appointment_timefrom']);?>">
									   </div>
									   
									    <div id="datestatus"> </div>
                                      <div class="form-group col-md-6">
                                        <label class=" control-label"><b>End Time:</b></label>
                                       <input type="time" name="end" id="end" class="form-control" value="<?php echo htmlentities($row['appointment_timeto']);?>">
									   </div>
									    <span id="availability"></span>
                              </div>
							<?php
							if($row['communication_mode'] == "Messenger") {
							?>
							 <div class="form-row">
                                      <div class="form-group col-md-12">
									  <br>
                                        <label class=" control-label"><b>Clinic's Facebook:</b></label>
                                         <input type="hidden" class="form-control" name="link" id="inputEmail4" value="N/A">USePofficial
										  <input type="hidden" class="form-control" name="facebook" id="inputEmail4" value="https://web.facebook.com/USePofficial">
                                      </div>
                              </div>
                               <?php
							   }if($row['communication_mode'] == "Google Meet" || $row['communication_mode'] == "Zoom" ) {
							   ?>
							     <div class="form-row">
                                      <div class="form-group col-md-12">
                                        <label class=" control-label"><b>Google meet link:</b></label>
                                         <input type="text" class="form-control" name="link" id="inputEmail4" value="<?php echo htmlentities($row['appointment_meetinglink']);?>">
                                      </div>
                              </div> 
							   
							   <?php
							   }if($row['communication_mode'] == "Cellphone" || $row['communication_mode'] == "Face to Face") {
							   ?>
							    <div class="form-row">
                                      <div class="form-group col-md-12">
									  <br>
                                         <input type="hidden" class="form-control" name="link" id="inputEmail4" value="Voice Call">
										  <input type="hidden" class="form-control" name="contact" id="inputEmail4" value="09460085327">
                                      </div>
                              </div>
							   <?php
							   }
							   ?> 
							 </div> 	
                              <br>	
                      <div class="modal-footer">
                        <button type="button" class="btn btn-danger"  data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success" name="resched">Set</button>
                      </div>            
                     
                 

                          </form>
                        </div>
                      </div>
                    
                    </div>
                  </div>
                </div>
<script>
const picker = document.getElementById('appdate');
picker.addEventListener('input', function(e){
  var day = new Date(this.value).getUTCDay();
  if([0].includes(day)){
    e.preventDefault();
    this.value = '';
    $('#closed').html('<span class="text-danger">Closed on Sunday!</span>');
  }else{
   $('#closed').html('<span class="text-danger"></span>');
	  }
})
</script>

