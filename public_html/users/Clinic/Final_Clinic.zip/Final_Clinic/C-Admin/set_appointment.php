 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
 <div class="modal fade " id="exampleModalLong<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header" style="background-color: #2B4550">
                        <h5 class="modal-title" id="exampleModalLongTitle" style="color: #FFFFFF"><?php echo htmlentities($row['patient_id']);?></h5>
                        <button type="button" class="close" data-dismiss="modal" style="color: #FFFFFF" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>


                      <div class="modal-body c">
                        <div class="container" style="border: 1px solid black; margin-top: 10px; padding: 20px; border-radius: 10px;">
                              <div class="id-picture"><img src="image/female_user.png" style="max-width: 100%;">
                              
                              <a href="Admin-PatientList.php"><button class="btn btn-danger btn-sm" style="width: 100%; margin-top: 5px; font-size: 10px;"><i class="fas fa-exclamation-triangle"></i> View Medical Info/History
                              </button></a></div>

                              <h5 class="font-weight-bold" style="margin-bottom: 20px; margin-top: 10px;">Patient Basic Information</h5> 
                              <h6 class="font-weight-bold">ID Number: <span class="font-weight-lighter ml-6"> <?php echo htmlentities($row['patient_id']);?></span></h6> 
                              <h6 class="font-weight-bold">Name: <span class="font-weight-lighter ml-2"> <?php echo htmlentities($row['first_name']);?> <?php echo htmlentities($row['last_name']);?></span></h6>								
                  							  <?php
                            			$date= date('Y-m-d');
                            			$agetotal=$row['birth_date'];
                            			$diff = date_diff(date_create($agetotal), date_create($date));
                            				?>
                              <h6 class="font-weight-bold">Age: <span class="font-weight-lighter ml-6"><?php echo $diff->format('%y');?>&nbsp;years old </span></h6> 
                              <h6 class="font-weight-bold">Civil Status: <span class="font-weight-lighter ml-6">  <?php echo htmlentities($row['civil_status']);?></span></h6> 
                              <h6 class="font-weight-bold">Sex: <span class="font-weight-lighter ml-2"><?php echo htmlentities($row['sex']);?></span></h6>
                              <h6  class="font-weight-bold">Year level: <span class="font-weight-lighter ml-2"> <?php echo htmlentities($row['year_level']);?></span></h6>
							   <h6 class="font-weight-bold">Course/Department: <span class="font-weight-lighter ml-2"> <?php echo htmlentities($row['section']);?></span></h6>
                            
                         <br>
                         <br>
                          <h5 class="font-weight-bold">Complaints: </h5> 
                          <div class="complaints"> 
                          <h6  class="font-weight-bold"><?php echo htmlentities($row['problems']);?></h6>
        
                          </div>
                          <br>
                          </div>
                      </div>
                  
                      <div class="modal-footer">
                        <button type="button" class="btn btn-success" data-dismiss="modal" data-toggle="modal" href="#exampleModalLong2<?php echo $row['id']; ?>">Accept</button>
                      </div>
                    </div>
                  </div>
                </div>
			<!--set appointment modal-->
				
				 <div class="modal fade " id="exampleModalLong2<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header" style="background-color: #2B4550">
                        <h5 class="modal-title" id="exampleModalLongTitle" style="color: #FFFFFF">SET APPOINTMENT</h5>
                        <button type="button" class="close" data-dismiss="modal" style="color: #FFFFFF" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body c">
                        <div class="container">
                          <form method="post" action="addappointment.php">  

       
                            <div class="row">
                            <div class="col-sm">
                              <div class="appointment_box">
                               <h5 class="font-weight-bold">Type of Consultation:<input type="hidden" name="type" class="form-control" value="<?php echo htmlentities($row['consultation_type']);?>"> <span class="font-weight-lighter ml-6"><?php echo htmlentities($row['consultation_type']);?></span></h5> 
							   
							   
                                <h5 class="font-weight-bold">Mode of Communication:<input type="hidden" name="mode" class="form-control" value="<?php echo htmlentities($row['communication_mode']);?>"> <span class="font-weight-lighter ml-6"><input type="hidden" name="mode2" class="form-control" value="<?php echo htmlentities($row['communication_mode']);?>"> <span class="font-weight-lighter ml-6"><?php echo htmlentities($row['communication_mode']);?></span></h5> 
                                <br>
		
                              <h6 class="font-weight-bold">Patient ID:  <input type="hidden" name="id" class="form-control" value="<?php echo htmlentities($row['patient_id']);?>"> <span class="font-weight-lighter ml-6"><u><?php echo htmlentities($row['patient_id']);?></u></span></h6> 
                              <h6 class="font-weight-bold">Patient Name:  <input type="hidden" name="name" class="form-control" value=" <?php echo htmlentities($row['name']);?>"> <span class="font-weight-lighter ml-2"><u> <?php echo htmlentities($row['name']);?></u></span></h6>
                               <h6 class="font-weight-bold">Email: <input type="hidden" name="email" class="form-control" value="<?php echo htmlentities($row['email_add']);?>"><span class="font-weight-lighter ml-6"><u><?php echo htmlentities($row['email_add']);?></u></span></h6> 
                          
                              
                              <br> 
							
                              <div class="form-row">
                                      <div class="form-group col-md-6">
                                        <label class=" control-label"><b>Date</b></label>
                                        <input type="date" name="date" id="appdate"  class="form-control" onChange="getDay(this.value);" min="<?php echo date('Y-m-d');?>" required>
										 <span id="closed"></span>
								 <input type="hidden" name="patient_id" class="form-control" value="<?php echo htmlentities($row['patient_id']);?>">
								 <input type="hidden" name="id" class="form-control" value="<?php echo htmlentities($row['id']);?>"> 
								
                                      </div>
									  </div>
									
									   <div class="form-row">
									  <div id="datestatus"> </div>
                                      <div class="form-group col-md-6">
                                        <label class=" control-label"><b>Start Time:</b></label>
                                       <input type="time" name="start" id="start" class="form-control" required>
									   </div>
									   
									    <div id="datestatus"> </div>
                                      <div class="form-group col-md-6">
                                        <label class=" control-label"><b>End Time:</b></label>
                                       <input type="time" name="end" id="end" class="form-control" required>
									   </div>
									    <span id="availability"></span>
                              </div>
							<?php
							if($row['communication_mode'] == "Messenger") {
							?>
							 <div class="form-row">
                                      <div class="form-group col-md-12">
									  <br>
                                        <label class=" control-label"><b>Clinic's Facebook:</b></label>
                                         <input type="hidden" class="form-control" name="link" id="inputEmail4" value="N/A">USePofficial
										  <input type="hidden" class="form-control" name="facebook" id="inputEmail4" value="https://web.facebook.com/USePofficial">
                                      </div>
                              </div>
                               <?php
							  }if($row['communication_mode'] == "Google Meet" || $row['communication_mode'] == "Zoom" ) {
							   ?>
							     <div class="form-row">
                                      <div class="form-group col-md-12">
                                        <label class=" control-label"><b>Meeting link:</b></label>
                                         <input type="text" class="form-control" name="link" id="inputEmail4" placeholder="Paste google meet link here">
                                      </div>
                              </div> 
							   
							   <?php
							   }if($row['communication_mode'] == "Cellphone" || $row['communication_mode'] == "Face to Face") {
							   ?>
							    <div class="form-row">
                                      <div class="form-group col-md-12">
									  <br>
                                         <input type="hidden" class="form-control" name="link" id="inputEmail4" value="Voice Call">
										  <input type="hidden" class="form-control" name="contact" id="inputEmail4" value="09460085327">
                                      </div>
                              </div>
							   <?php
							   }
							   ?> 
							 </div> 	
                              <br>	
                      <div class="modal-footer">
                        <button type="button" class="btn btn-danger"  data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success" name="appointment">Set</button>
                      </div>            
                     
                 

                          </form>
                        </div>
                      </div>
                    
                    </div>
                  </div>
                </div>
<script>
const picker = document.getElementById('appdate');
picker.addEventListener('input', function(e){
  var day = new Date(this.value).getUTCDay();
  if([0].includes(day)){
    e.preventDefault();
    this.value = '';
    $('#closed').html('<span class="text-danger">Closed on Sunday!</span>');
  }else{
   $('#closed').html('<span class="text-danger"></span>');
	  }
})
</script>
<script>  
 $(document).ready(function(){  
   $('#end').keyup(function(){

     var appdate = $(this).val();
	  var start = $(this).val();
	   var end = $(this).val();

     $.ajax({
      url:'check.php',
      method:"POST",
      data:{app_date:appdate, start_time:start, end_time: end},
      success:function(data)
      {
       if(data != 0)
       {
        $('#availability').html('<span class="text-danger">Selected time is not available</span>');
        $('#register').attr("disabled", true);
       }
       else
       {
        $('#availability').html('<span class="text-success"> Available</span>');
        $('#register').attr("disabled", false);
       }
      }
     })

  });
 });  
</script>


