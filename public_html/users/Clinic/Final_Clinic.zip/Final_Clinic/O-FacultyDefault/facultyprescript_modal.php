 <link rel="stylesheet" type="text/css" href="css/clinic_style.css">
             <div class="modal fade " id="requiredlab<?php echo $consult_id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document" >
                    <div class="modal-content" id="content<?php echo $consult_id ?>" style="width: 100%;">
                      <div class="modal-header" style="background-color: #2B4550">
                        <h5 class="modal-title" id="exampleModalLongTitle" style="color: #FFFFFF">&nbsp; PRESCRIPTION </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: #FFFFFF">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>

                      <div class="modal-body" id="prescript">
                      <div class="container" id="container">


                      <div class = "head">  
                        
                        <h6 class="font-weight-bold">Republic of the Philippines</h6> 
                        <h6 class="font-weight-bold" style= "font-family: Old English Text MT;">University of Southeastern Philippines</h6>
                        <h6 class="font-weight-bold">Tagum-Mabini Campus</h6> 
                        <h6 class="font-weight-bold">Apokon, Tagum City</h6> 
                        <br>
                      </div>
                        <hr width=”50%″ size="10">
                        <hr width=”50%″ size="10">
                       
                      
                      <br>
                        <h6>Date: <span class="font-weight-lighter ml-2"> <?php echo $row['prescription_date_issued']; ?></span></h6>
                        <h6>Name: <span class="font-weight-lighter ml-2"> <?php echo $row['name']; ?> </span></h6>
                        <h6>Email Address: <span class="font-weight-lighter ml-2"> <?php echo $row['email_add']; ?> </span></h6>
                        

                        <img class="pr" src="image/pr.png" alt="img" width="20%">
                         <br> 
                         <br>
                         <br><br>
                          <h6 class="font-weight-bold" style="margin-left: 5%;"><?php echo nl2br ($row['prescription_details']);?> </h6> 
                          <br>
                          <br>
                          
                          <div style="display: inline-block; text-align: right; margin-left: 120px" id="other" >
                            <h6 class="font-weight-bold"><input type="text" readonly="" value="CHRYSTELLER O. CLET, MD. FPAFP"  style="text-align: center;border-left:none;border-right: none;border-top: none;outline: none;cursor: default; width: 250px;"></h6> <br></input>

                      <h6 class="font-weight-normal">Lic. No.<span class="font-weight-lighter ml-2"></span><input type="text" readonly="" value=""  style="text-align: center;border-left:none;border-right: none;border-top: none;outline: none;cursor: default;width: 250px;"></input>
                      </h6> 
                      <h6 class="font-weight-normal">PTR No. <span class="font-weight-lighter ml-2"></span><input type="text" readonly="" value=""  style="text-align: center;border-left:none;border-right: none;border-top: none;outline: none;cursor: default;width: 250px;"></input>
                      </h6>
                      <h6 class="font-weight-normal">S2. <span class="font-weight-lighter ml-2"></span><input type="text" readonly="" value=""  style="text-align: center;border-left:none;border-right: none;border-top: none;outline: none;cursor: default;width: 250px;"></input>
                      </h6>

                    </div>

                          <br>
                          <br>
                     
                          </div>   
                        </div>
                    
                      <div class="modal-footer">
                      
                        <button type="button" class="btn btn-success" id="btnPrint<?php echo $consult_id ?>">Print</button>
                      </div>
                      <img id="logo" src="image/logo.png"  style="position: absolute;transform: translate(100px, 350px);opacity: .15 " />
                    </div>
                  </div>
                  </div>
                </div>   

 <script type="text/javascript">

                    document.getElementById("btnPrint<?php echo $consult_id ?>").onclick = function () {

                                    printElement(document.getElementById("content<?php echo $consult_id ?>"));

                                };

                                function printElement(elem) {

                                    var domClone = elem.cloneNode(true);

                                    

                                    var $printSection = document.getElementById("printSection");

                                    

                                    if (!$printSection) {

                                        var $printSection = document.createElement("div");

                                        $printSection.id = "printSection";

                                        document.body.appendChild($printSection);

                                    }

                                    

                                    $printSection.innerHTML = "";

                                    $printSection.appendChild(domClone);

                                    window.print();

                                }

                </script>
                <style>
                   @media screen {

                        #printSection {

                            display: none;

                        }

                    }

                    @media print {

                        body * {

                            visibility: hidden;

                        }

                        #printSection,

                        #printSection *,#container {

                            visibility: visible;
                            max-height: 100%;
                            

                        }

                        #printSection {

                            position: absolute;

                            left: 0;

                            top: 0;


                            
                        }
                        .close{
                          display: none;
                        }

                        .btn{
                          display: none;
                        }
                        #printSection, #container{
                          width: 50%;

                        }
                        .head,hr,.modal-dialog,#requested{
                          width: 47%;
                        }
                        hr{
                          margin-left: 10px !important;
                        }
                        .modal-content{
                          width: 51%;
                        }
                        .pr{
                          width: 10%;
                          height: 10%;
                          
                        }
                        #other{
                          margin-left: 165px!important;
                        }


                        
                        

                        

                    }

                </style>