  <!DOCTYPE html>
  <html lang="en">
   <?php
  session_start();
  include('connect.php');
  if(!isset($_SESSION['id'])){
  echo '<script> alert("Please Login first!!!") 
  window.location="../index.php";
  </script>';
    
}

$id = $_SESSION['id'];

$count_sql="SELECT * from notif where message_status='Delivered' AND user_id='$id'";

          $result = mysqli_query($db, $count_sql);

          $count = 0;

          while ($row = mysqli_fetch_assoc($result)) {                             

            $count++;

                              }


function timeago($datetime, $full = false) {
  date_default_timezone_set('Asia/Manila');
  $now = new DateTime;
  $ago = new DateTime($datetime);
  $diff = $now->diff($ago);
  $diff->w = floor($diff->d / 7);
  $diff->d -= $diff->w * 7;
  $string = array(
    'y' => 'yr',
    'm' => 'mon',
    'w' => 'week',
    'd' => 'day',
    'h' => 'hr',
    'i' => 'min',
    's' => 'sec',
  );
  foreach ($string as $k => &$v) {
    if ($diff->$k) {
      $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
    } 
    else {
      unset($string[$k]);
    }
  }
  if (!$full) {
    $string = array_slice($string, 0, 1);
  }
  
  return $string ? implode(', ', $string) . '' : 'just now';
}

  ?>
    <head>
      <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
      <!-- Twitter meta-->
      <meta property="twitter:card" content="summary_large_image">
      <meta property="twitter:site" content="@pratikborsadiya">
      <meta property="twitter:creator" content="@pratikborsadiya">
      <!-- Open Graph Meta-->
      <meta property="og:type" content="website">
      <meta property="og:site_name" content="Vali Admin">
      <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
      <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
      <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
      <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
      <title>Home | Clinic</title>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- Main CSS-->
      <link rel="stylesheet" type="text/css" href="css/main.css">
      <link rel="stylesheet" type="text/css" href="css/home.css">
      <link rel="stylesheet" type="text/css" href="css/upstyle.css">

      <!-- Font-icon css-->
          <link rel="stylesheet" type="text/css" href="css/all.min.css">
      <link rel="stylesheet" type="text/css" href="css/fontawesome.min.css">
      <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


    </head>
      <body class="app sidebar-mini rtl">
      <!-- Navbar-->


        
      <header class="app-header">
         
   
      </header>

      <!-- Sidebar menu-->
      <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
        <aside class="app-sidebar">
        <div class="app-sidebar__user">
          <img class="app-sidebar__user-avatar" src="image/logo.png" width="20%" alt="img">
          <div>
            <p class="app-sidebar__user-name font-sec" style="margin-top: 8px;">STUDENT PORTAL</p>
          </div>
        </div>

        <hr>



        <ul class="app-menu font-sec">
          <li class="p-2 sidebar-label"><span class="app-menu__label">DASHBOARD</span></li>
          <li><a class="app-menu__item" href="Defaultstudent.html"><i class="app-menu__icon fa fa-bullhorn"></i><span class="app-menu__label">Announcements</span></a></li>
          <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fas fa-users"></i><span class="app-menu__label">Student's Affair & Services</span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
              <li><a class="treeview-item" href="#">Home</a></li>
              <li><a class="treeview-item" href="#">Student Discipline</a></li>
              <li><a class="treeview-item" href="#">Student Organization</a></li>
              <li><a class="treeview-item" href="#">Student Labor</a></li>
              <li><a class="treeview-item" href="#">Request for Good Moral</a></li>
            </ul>
          </li>


          <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fas fa-handshake-o"></i><span class="app-menu__label">Guidance Services</span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
              <li><a class="treeview-item active" href="#">Home</a></li>
              <li><a class="treeview-item" href="#">Counselling</a></li>
              <li><a class="treeview-item" href="#">Evaluation</a></li>
            </ul>
          </li>

            <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fas fa-handshake-o"></i><span class="app-menu__label">Scholarship Services  </span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
              <li><a class="treeview-item" href="#">Home</a></li>
              <li><a class="treeview-item" href="#">Scholarship Data Form</a></li>

            </ul>
          </li>



           <li class="treeview"><a class="app-menu__item active" href="#" data-toggle="treeview"><i class="app-menu__icon fas fa-medkit"></i><span class="app-menu__label">Health Services  </span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
              <li><a class="treeview-item" href="Home.php">Home</a></li>
              <li><a class="treeview-item" href="Clinic_Privacy-Policy.php">Consultation</a></li>
              <li><a class="treeview-item" href="StudentConsultationHistory.php">Consultation History</a></li>
              <li><a class="treeview-item" href="Prescription.php">Prescription</a></li>
              <li><a class="treeview-item" href="RequestMedCert.php">Request for Medical Certificate</a></li>
              <li><a class="treeview-item" href="RequestMedRecsCert.php">Request for Medical Records Certification</a></li>


            </ul>
          </li>


     

          
        </ul>
      </aside>


       <!--navbar-->

          <main class="app-content">
            
        <div class="app-title">
           <div><!-- Sidebar toggle button--><a class="app-sidebar__toggle fa fa-bars" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a></div>
          <ul class="app-nav">
            <li>
                 <?php
                  $uid=$_SESSION['id'];
                  $sql = "SELECT * from student where Student_id='$uid' ";
                  $res = $db->query($sql);
                  while($row = $res->fetch_assoc()) {?>
                <a class="appnavlevel"> Hi, <?php echo htmlentities($row["first_name"]);?></a>
              </li>
        <?php
        }?>
             <!-- <li class="app-search">
                   <input class="app-search__input" type="search" placeholder="Search">
                  <button class="app-search__button"><i class="fa fa-search"></i></button>
              </li>-->  
     <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Show notifications"><b style="color: red;"><?php echo $count;  ?></b><i class=" fas fa-bell fa-lg mt-2"></i></a>
            <ul class="app-notification dropdown-menu dropdown-menu-right">
              <li class="app-notification__title">You have <?php echo $count;  ?> new notifications.</li>
              <div class="app-notification__content">

                <?php 
                $count_sql="SELECT * from notif where message_status='Delivered' AND user_id='$id'  order by time desc";

                $result = mysqli_query($db, $count_sql);

                while ($row = mysqli_fetch_assoc($result)) { 
                  $intval = intval(trim($row['time']));
                  if ($row['message_status']=='Delivered' && $row['user_id']=='$id') {

                    
                    echo'
                  <b><li><a class="app-notification__item" href="javascript:;"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-primary"></i><i class="fa fa-envelope fa-stack-1x fa-inverse"></i></span></span>
                    <div>
                      <p class="app-notification__message">'.$row['message_body'].'</p>
                      <p class="app-notification__meta">'.timeago($row['time']).'</p>
                      <p class="app-notification__message"><form method="POST" action="notif_stat.php">
                      <input type="hidden" name="notif_id" value="'.$row['notif_id'].'">
                      <input type="submit" name="open_notif" value="Open Message">
                      </form></p>
                    </div></a></li></b>
                    ';
                  }else{
                    echo'
                  <li><a class="app-notification__item" href="javascript:;"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-primary"></i><i class="fa fa-envelope fa-stack-1x fa-inverse"></i></span></span>
                    <div>
                      <p class="app-notification__message">'.$row['message_body'].'</p>
                      <p class="app-notification__meta">'.timeago($row['time']).'</p>
                      <p class="app-notification__message"><form method="POST" action="notif_stat.php">
                      <input type="hidden" name="notif_id" value="'.$row['notif_id'].'">
                      <input type="submit" name="open_notif" value="Open Message">
                      </form></p>
                    </div></a></li>
                    ';
                  }
                  

                                    }
                ?>
            </ul>
          </li>
              
                 <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="text-warning fas fa-user-circle fa-2x"></i></a>
            <ul class="dropdown-menu settings-menu dropdown-menu-right">
              <li><a class="dropdown-item" href="user-profiles.html"><i class="fa fa-user fa-lg"></i> Profile</a></li>
              <li><a class="dropdown-item" href="page-login.html"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
            </ul>
          </li>
      
          </ul>
        </div>
        <div class="red"> 
          
        </div>

      <!-- Navbar-->

         <!--<div class="page-error tile">-->
 
           </div>   
</form>
<!---<div class="row">
<div class="col-md-6">
          <div class="tile ">
            <center><h4 class="mb-2">CALENDAR</h4></center>
              <div id="calendar"></div>
            </div>
          </div>
      <div class="col-md-6">
              <div style="background-color: #193541; padding: 12px 10px;">
                          <div class="info" style="color: #FFFFFF;"><center><h5 class="mb-2">Upcoming Schedules</h5></center>
                          </div>  
                        </div>
              <div class="tile">
              <div id="external-events">
        <?php
        $limit=5;
        $sql="Select consultation.consultation_type,date_format(consultation.appointment_date,'%M %d, %Y')as appointment_date,consultation.appointment_timefrom ,consultation.consultation_duration ,CONCAT(student.first_name,' ', student.last_name) as name from consultation join student on consultation.patient_id=student.Student_id where status='Pending' AND appointment_date is not null order by appointment_date,appointment_timefrom,consultation_duration ASC LIMIT $limit";
        
       $res = $db->query($sql);
      $cnt=1;
      
      while($row = $res->fetch_assoc()) {
      $appointment_start= new DateTime($row['appointment_timefrom']);
      $appointment_end= new DateTime($row['consultation_duration']);
         ?>
                <div class="fc-event"><h6>  <?php echo htmlentities($row['consultation_type']);?>-<?php echo htmlentities($row['name']);?><br></h6> Date: <?php echo htmlentities($row['appointment_date']);?><br> Time: <?php echo $appointment_start->format('g:i a');?> - <?php echo $appointment_end->format('g:i a');?></div>
        <?php
        }
        if ($res->num_rows == 0) {
        ?>
        
        <div class="fc-event"><h6> No Upcoming Events! </h6></div>
        <?php 
        }
        ?>
           
              </div>
            </div>
          </div>
        </div>
        -->

<section class="showcase" style="background-image: url('image/welcome.png'); background-repeat: no-repeat;">
  <div class="content">
    <br>
    <ul class="shortcut">
        <li class="shortcut_links"><a href="#about" style="color: #FF5B5B; font-weight: bold;">Home</a></li>&emsp;
        <li class="shortcut_links"><a href="#about">About</a></li>&emsp;
  <li class="shortcut_links"><a href="#services">Services</a></li>&emsp;
  <li class="shortcut_links"><a href="#personnel">Personnel</a></li>&emsp;
  <li class="shortcut_links"><a href="#calendar">Schedules</a></li>&emsp;&emsp;&emsp;
</ul>
    <div class="row">
      <div class="column">
        <img src="image/online-doctor-animate.svg" alt="img">
      </div>

      <div class="columnx">
        <h1>USeP Patient Portal</h1>
        <p>The USeP Patient Portal allows you to view your medical records and schedule appointments to our clinic through the internet.</p>
        <div id="container">
          <a class="learn-more" href="#about">
            <span class="circle" aria-hidden="true">
              <span class="icon arrow"></span>
            </span>
              <span class="button-text">Learn More</span>
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<section id="about">
  <center>
  <h2>ABOUT THE OFFICE</h2>
  <br>
  <div style="height: 3px; width: 50px; background-color: white;"></div>
  </center>
  <br>
  <p style="text-align: justify;">
    "The clinic is a health facility where patients can seek primary health and comfort for any sickness or disease. The health staff are government servants. We serve the patients in all forms of illness whenever feasible with our facilities. We are obliged to refer severe cases to higher facilities like hospital and laboratories for further treatment and management. Everyone is encourage to visit the clinic for any health problem to avoid further complication. We believe that prevention is better than cure."
  </p><br>
  <hr style="border-color:lightgray;"><br>
  <h2>MANDATE</h2><br>

  <div class="mvg">
  <h2 class="mandate" style="color: #FF5B5B"><i class="far fa-eye"></i> Vision</h2><br>
  <p>The University Health Service envisions itself to be the leader in health maintenance in providing basic health care to its all constituents by meeting the needs of each and every patients not only in the primary treatment of ailments and injuries but also in the prevention of illness through easy access of health care and education for each one in the realm of good health practices and behavior.</p>
  </div>
  <div class="mvg">
  <h2 style="color: #FF5B5B"><i style="font-size:24px" class="fa">&#xf135;</i> Mission</h2><br>
  <p>To be the provider of holistic health care for all University constituents by:</p><br>
  <i style="font-size:24px" class="fa">&#xf046;</i> Providing basic health care services in both medical and dental fields in cases if immediate and intermediate needs of the clients.<br><br>
  <i style="font-size:24px" class="fa">&#xf046;</i> Promoting fitness and well being through health education on diseases and illnesses and health maintenance values aimed towards prevention rather than treatment.
  </div>
  <div class="mvg">
  <h2 style="color: #FF5B5B"><i style="font-size:24px" class="fa">&#xf192;</i> Goal</h2><br>
  <i style="font-size:24px" class="fa">&#xf046;</i> To build a healthy community and create an environment conducive for learning and developing intellectual and technical skills to be able to meet high standards of excellence in education.<br><br>
  <i style="font-size:24px" class="fa">&#xf046;</i> To maintain, enhance and forge strong partnerships/cooperation with other heads of office in the University in order to achieve standards of excellence in primary health care delivery so as to keep abreast with the University’s vision and mission.<br><br>
  <i style="font-size:24px" class="fa">&#xf046;</i> To train and educate clients on prevention of illnesses and achieve and good health through health education and training seminars on updates of health maintenance and environmental sanitation.
  </div>

</section>

<section id="services" style="background-image: url('image/services.png'); background-repeat: no-repeat;">
  <center>
  <h2 style="color: gray;">SERVICES OFFERED</h2><br>
  <div style="height: 3px; width: 50px; background-color: gray;"></div>
  <br><br>
  </center>
<div class="container">
  <div class="row flex-items-xs-middle flex-items-xs-center" style="align-items: center; text-align: center;">

    <!-- Table #1  -->
    <div class="col-lg-5 col-lg-4">
      <div class="card text-xs-center">
        <div class="card-header">
          <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
width="50" height="50"
viewBox="0 0 172 172"
style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ff5b5b"><path d="M144.75864,21.70296c-9.58728,-9.69736 -23.35072,-14.82296 -39.79736,-14.82296c-5.99592,0 -11.41392,0.68112 -16.24024,1.94704c5.75168,4.16928 10.66056,9.66984 14.24504,16.24368c0.9116,1.6684 0.29584,3.75648 -1.37256,4.66464c-0.51944,0.28552 -1.0836,0.41968 -1.64432,0.41968c-1.21776,0 -2.39768,-0.64672 -3.02376,-1.79224c-5.35952,-9.82808 -17.80544,-21.4828 -32.29472,-21.37272c-26.79072,-0.11008 -50.87072,21.156 -50.87072,50.62992c0,12.6076 5.17376,21.63416 10.65368,31.19048c3.72896,6.50504 7.5852,13.23024 9.8384,21.414c1.31064,4.87448 2.47336,10.08952 3.5948,15.12912c4.56144,20.4508 8.86832,39.7664 23.23376,39.7664c10.00352,0 15.9788,-7.06232 15.9788,-18.89248c0,-14.6888 3.18888,-34.22456 5.56936,-47.54768c0.4472,-2.1672 2.07776,-2.93776 3.48816,-2.93776c0.02408,0 0.0516,0 0.07568,0c0.63296,0.01376 2.72792,0.25112 3.16136,2.8552c3.70488,20.30288 5.58656,36.3264 5.58656,47.6268c0,11.83016 5.97184,18.89248 15.9788,18.89248c14.30352,0 18.6104,-19.23648 23.16496,-39.60128c1.14552,-5.10496 2.32544,-10.3888 3.65672,-15.27016c2.26008,-8.2044 6.11632,-14.93304 9.84528,-21.43464c5.47992,-9.55976 10.65368,-18.58632 10.65368,-31.15264c0.15824,-14.44456 -4.50296,-26.88016 -13.48136,-35.95488z"></path></g></g></svg>
        </div>
        <div class="card-block">
          <h4 class="card-title"> 
            Dental Services
          </h4>
          <ul class="list-group">
            <li class="list-group-item">Dental Consultation and Treatment</li>
            <li class="list-group-item">Extraction</li>
            <li class="list-group-item">Dental Filling</li>
          </ul>
          <a href="#" class="btn btn-gradient mt-2">Schedule</a>
        </div>
      </div>
    </div>
    
     <!-- Table #1  -->
    <div class="col-lg-5 col-lg-4">
      <div class="card text-xs-center">
        <div class="card-header">
          <i style="font-size:48px" class="fa">&#xf21e;</i>
        </div>
        <div class="card-block">
          <h4 class="card-title"> 
            Medical Services
          </h4>
          <ul class="list-group">
            <li class="list-group-item">Free consultation and treatment</li>
            <li class="list-group-item">Referral to hospitals for severe cases</li>
            <li class="list-group-item">Suturing of minor cuts and wound</li>
            <li class="list-group-item">Treatment of emergency cases whenever necessary</li>
          </ul>
          <a href="#" class="btn btn-gradient mt-2">Schedule</a>
        </div>
      </div>
    </div>

 

  </div>
</div>
  
</section>

<section id="personnel">
  <center>
  <h2>STAFFS AND PERSONNEL</h2>
  <br>
  <div style="height: 3px; width: 50px; background-color: gray"></div><br>
  </center>

  <div class="gallery">
      <img src="image/zenaida.jpg" alt="John" style="width:100%;"><br>
      <h6 style="padding-top: 10px;">ZENAIDA TALATTAD</h6>
      <p style="font-size: 1.5vh;" class="title">Medical Director</p>
      <p><button class="email" style="font-size: 2vh;"><i class="fab fa-google-plus-g icon-10x"></i></button></p>
  </div>

  <div class="gallery">
      <img src="image/andres.jpg" alt="John" style="width:100%"><br>
      <h6 style="padding-top: 10px;">FRANCIS ANDRES</h6>
      <p style="font-size: 1.5vh;" class="title">Dentist</p>
      <p><button class="email" style="font-size: 2vh;"><i class="fab fa-google-plus-g icon-10x"></i></button></p>
  </div>


  <div class="gallery">
      <img src="image/salgado.jpg" alt="John" style="width:100%"><br>
      <h6 style="padding-top: 10px;">MILA SALGADO</h6>
      <p style="font-size: 1.5vh;" class="title">Dental Aide</p>
      <p><button style="font-size: 2vh;" class="email"><i class="fab fa-google-plus-g icon-10x"></i></button></p>
  </div>

  <div class="gallery">
      <img src="image/talob.jpg" alt="John" style="width:100%"><br>
      <h6 style="padding-top: 10px;">VIVIAN TALOB</h6>
      <p style="font-size: 1.5vh;" class="title">Nurse I</p>
      <p><button style="font-size: 2vh;" class="email"><i class="fab fa-google-plus-g icon-10x"></i></button></p>
  </div>

  <div class="gallery">
      <img src="image/staff.jpg" alt="John" style="width:100%">
      <h6 style="padding-top: 10px;">MARILYN ALCONEL</h6>
      <p style="font-size: 1.5vh;" class="title">Nurse II</p>
      <p><button style="font-size: 2vh;" class="email"><i class="fab fa-google-plus-g icon-10x"></i></button></p>
  </div>
</section>

<section id="sched" style="background-color: white; padding: 20px;">
<center>
  <br>
  <h2 style="color: gray;">SCHEDULES</h2>
  <br>
  <div style="height: 3px; width: 50px; background-color: gray"></div><br>
  </center>

<div class="row" style="padding-top: 20px;">
  <div class="col-lg-12">
    <div class="column" style="padding-left: 30px; padding-right: 30px;">
              <div class="col-lg-24"  id="calendar">
              </div>
    </div>

    <div class="column">
      <div>
        <div class="info" style="color: gray; padding-left: 30px;"><h5 class="mb-2"><i class="far fa-calendar-check icon-10x"></i> Events</h5>
        </div>  
      </div>
      
      <div class="tile" style="box-shadow: none; padding: 0px; padding-left: 30px; padding-right: 30px; ">
        <div id="external-events">
          <?php
          $limit=5;
          $sql="Select consultation.consultation_type,date_format(consultation.appointment_date,'%M %d, %Y')as appointment_date,consultation.appointment_timefrom ,consultation.consultation_duration ,CONCAT(student.first_name,' ', student.last_name) as name from consultation join student on consultation.patient_id=student.Student_id where status='Pending' AND appointment_date is not null order by appointment_date,appointment_timefrom,consultation_duration ASC LIMIT $limit";
        
          $res = $db->query($sql);
          $cnt=1;
      
          while($row = $res->fetch_assoc()) {
            $appointment_start= new DateTime($row['appointment_timefrom']);
            $appointment_end= new DateTime($row['consultation_duration']);
          ?>
          
            <div class="fc-event" style="background: linear-gradient(to right, rgb(255, 65, 108), rgb(255, 75, 43));"><h6>  <?php echo htmlentities($row['consultation_type']);?>-<?php echo htmlentities($row['name']);?><br></h6> Date: <?php echo htmlentities($row['appointment_date']);?><br> Time: <?php echo $appointment_start->format('g:i a');?> - <?php echo $appointment_end->format('g:i a');?></div>
          
            <?php
          }
            
            if ($res->num_rows == 0) {
            ?>
        
              <div class="fc-event" style="background: linear-gradient(to right, rgb(255, 65, 108), rgb(255, 75, 43)); border: none;"><h6> No Upcoming Events! </h6></div>
              <?php 
            }
              ?>          
        </div>
      </div>
   
  </div>
</div>
      
</section>


                     

        

        <!--</div>-->
      </main>
      <!-- Essential javascripts for application to work-->
      
      <script src="js/jquery-3.3.1.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/main.js"></script>
      <!-- The javascript plugin to display page loading on top-->
      <script src="js/plugins/pace.min.js"></script>
      <!-- Page specific javascripts-->
      <script type="text/javascript" src="js/plugins/bootstrap-notify.min.js"></script>
      <script type="text/javascript" src="js/plugins/sweetalert.min.js"></script>
      <script type="text/javascript">
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript" src="js/plugins/jquery.vmap.min.js"></script>
    <script type="text/javascript" src="js/plugins/jquery.vmap.world.js"></script>
    <script type="text/javascript" src="js/plugins/jquery.vmap.sampledata.js"></script>
    <script type="text/javascript" src="js/plugins/moment.min.js"></script>
    <script type="text/javascript" src="js/plugins/jquery-ui.custom.min.js"></script>
    <script type="text/javascript" src="js/plugins/fullcalendar.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
          /*$('#external-events .fc-event').each(function() {
      
          // store data so the calendar knows to render an event upon drop
          $(this).data('event', {
            title: $.trim($(this).text()), // use the element's text as the event title
            stick: true // maintain when user navigates (see docs on the renderEvent method)
          });
      
          // make the event draggable using jQuery UI
          $(this).draggable({
            zIndex: 999,
            revert: true,      // will cause the event to go back to its
            revertDuration: 0  //  original position after the drag
          });
      
        });*/
        var calendar = $('#calendar').fullCalendar({
          editable: true,
          header: {
            left: 'prev,next today',
            center: 'title', 
            right: 'month,agendaWeek,agendaDay'
          },
          events:'calendarview.php',  
          selectable:true,
          /*droppable: true, // this allows things to be dropped onto the calendar
          drop: function() {
            // is the "remove after drop" checkbox checked?
            if ($('#drop-remove').is(':checked')) {
              // if so, remove the element from the "Draggable Events" list
              $(this).remove();
            }
          }*/
        });
      
      
      });

      function onload(){

      }

    </script>
     <?php  
      if ($count!=0) { ?>
        <script>
    $(document).ready(function(){
        $("#myModal").modal('show');
    });
</script>
      <?php
    }
      ?>

      <script type="text/javascript">
           function openForm() {
          document.body.classList.add("myForm");

      }

        function closeForm() {
          document.body.classList.remove("myForm");

      }

      </script>

<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script> -->
      

     <div id="myModal" class="modal fade" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Notifications</h5>
            </div>
            <div class="modal-body">
                <p>You have <?php echo $count;  ?> unread notifications</p><br>
                
                   
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                
            </div>
        </div>
    </div>
</div>
    </body>
  </html>