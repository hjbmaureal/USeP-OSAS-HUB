<?php
session_start();
include("conn.php"); 

if(isset($_POST['submit'])){

     $uid = $_POST['uname'];
     $password = $_POST['pword'];
    $data = array();


    $sql = "call spLogIn(?,?)";
    $stmt = mysqli_stmt_init($conn);
                
    if (!mysqli_stmt_prepare($stmt,$sql)){
        echo "SQL statement failed!";
    } else {
        mysqli_stmt_bind_param($stmt,"ss", $uid,$password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $resultCheck = mysqli_num_rows($result);
        if ($resultCheck > 0){
            while ($row = mysqli_fetch_assoc($result)){ 
                $data[] = $row;
                $_SESSION['id'] = $row['username'];
                $_SESSION['fullname'] = $row['name'];
                $_SESSION['usertype'] = $row['usertype'];
                $_SESSION['office'] = $row['staff_office'];
                $_SESSION["patinfo"] = $row['patinfo_status'];
                $_SESSION['user_signature'] = base64_encode ($row['e_signature']);
                if($_SESSION['id']=='superadmin'){         
                    echo '<script type="text/javascript">'; 
                     echo 'location.href= "superadmin/edwin";';
                     echo '</script>';
                }
                if ($_SESSION['usertype']=='Student'){
                    $_SESSION['sl_status'] = $row['sl_status'];
                     echo '<script type="text/javascript">'; 
                     echo 'window.location= "O-StudentDefault";';
                     echo '</script>';
            
                }
                if ($_SESSION['usertype']=='Staff'){
                    $access_level = $row['access_level'];
                    if ($_SESSION['office'] ='OSAS' && $access_level = 1){
                         echo '<script type="text/javascript">'; 
                         echo 'window.location= "C-Admin/Admin-Dashboard.php";';
                         echo '</script>';
                    } else if ($access_level = 1){
                         echo '<script type="text/javascript">'; 
                         echo 'window.location= "C-Admin/Admin-Dashboard.php";';
                         echo '</script>';
                    }
                }
                if ($_SESSION['usertype']=='Faculty' && $access_level = 1){
                     echo '<script type="text/javascript">'; 
                     echo 'window.location= "M-FacultyHead";';
                     echo '</script>';
                }
            }
        } else {
                 echo '<script type="text/javascript">'; 
                 echo 'window.location= "index.php";';
                 echo '</script>';
            }
    }

}