<?php
session_start();
include("conn.php"); 

if(isset($_POST['submit'])){

    $uname = $_POST['uname'];

    

    if ($uname != ""){

        $sql_query = "select * from student where student_id='".$uname."'";
        $result = mysqli_query($conn,$sql_query);
        $row = mysqli_fetch_array($result);
        $_SESSION['patient_id'] = strtoupper($uname);
        header("Location: requestmedcert.php");


}
}
?>